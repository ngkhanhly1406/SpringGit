package khly.codelean.project2.login;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.authentication.dao.DaoAuthenticationProvider;
import org.springframework.security.config.annotation.authentication.configuration.AuthenticationConfiguration;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.web.SecurityFilterChain;

import javax.sql.DataSource;

@Configuration
public class WebSecurityConfig {

	@Autowired
	private DataSource dataSource;

	@Bean
	public UserDetailsService userDetailsService() {
		return new CustomUserDetailsService();
	}

	@Bean
	public PasswordEncoder passwordEncoder() {
		return new BCryptPasswordEncoder();
	}

	@Bean
	public DaoAuthenticationProvider authenticationProvider() {
		DaoAuthenticationProvider authProvider = new DaoAuthenticationProvider();
		authProvider.setUserDetailsService(userDetailsService());
		authProvider.setPasswordEncoder(passwordEncoder());
		return authProvider;
	}

	@Bean
	public SecurityFilterChain securityFilterChain(HttpSecurity http) throws Exception {
		http
				.authorizeHttpRequests(authorizeRequests ->
						authorizeRequests
								.requestMatchers("/admin/**").hasRole("ADMIN") // Chỉ ADMIN mới được vào trang admin

								/*.requestMatchers("/cart/**", "/checkout/**").authenticated()*/
								.requestMatchers("/shop-list-no-sidebar").permitAll() // Thay thế antMatchers bằng requestMatchers
								/*.requestMatchers("/cart/**", "/add/**").authenticated() */// Bắt buộc xác thực với các URL giỏ hàng và thêm sản phẩm
								.anyRequest().permitAll()
				)

				.formLogin(formLogin ->
						formLogin
								.loginPage("/login") // Trang đăng nhập tùy chỉnh của bạn
								.usernameParameter("email") // Tên trường cho tên người dùng (username)
								.passwordParameter("password") // Tên trường cho mật khẩu
								.defaultSuccessUrl("/", true)
								.failureUrl("/login?error") // URL khi đăng nhập thất bại
								.permitAll()
				)

				.logout(logout ->
						logout
								.logoutUrl("/logout") // URL thực hiện logout
								.logoutSuccessUrl("/") // Trang chuyển hướng sau khi logout thành công
								.permitAll()
				);

		return http.build();
	}

	/*@Bean
	public SecurityFilterChain securityFilterChain(HttpSecurity http) throws Exception {
		http
				.authorizeHttpRequests(authorizeRequests ->
						authorizeRequests
								.requestMatchers("/", "/product", "/faq", "/blog", "/contact", "/product-detail", "/login", "/register", "/my-account").permitAll() // Cho phép không hạn chế truy cập các trang này// Cho phép không hạn chế truy cập trang đăng nhập
								.anyRequest().authenticated() // Các yêu cầu khác cần xác thực
				)
				.formLogin(formLogin ->
						formLogin
								.loginPage("/login") // Trang login tùy chỉnh của bạn
								.usernameParameter("email")
								.passwordParameter("password") // Thay đổi nếu tên trường khác
								.defaultSuccessUrl("/", true)
								.failureUrl("/login?error") // URL khi đăng nhập thất bại
								.permitAll()
				)
				.logout(logout ->
						logout.logoutSuccessUrl("/").permitAll()
				);

		return http.build();
	}*/




	@Bean
	public AuthenticationConfiguration authenticationConfiguration() {
		return new AuthenticationConfiguration();
	}
}



