package khly.codelean.project2.controller;

import jakarta.servlet.http.HttpSession;
import khly.codelean.project2.cart.ShoppingCart;
import khly.codelean.project2.dao.CustomerRepository;
import khly.codelean.project2.dao.OrderRepository;
import khly.codelean.project2.dao.ProductRepository;
import khly.codelean.project2.entity.*;
import khly.codelean.project2.login.User;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;


import java.math.BigDecimal;
import java.security.Principal;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

@Controller
@RequestMapping("/cart")
public class CartController {

    private final ProductRepository productRepository;

    private final CustomerRepository customerRepository;

    @Autowired
    private OrderRepository orderRepository;

    public CartController(ProductRepository productRepository, CustomerRepository customerRepository) {
        this.productRepository = productRepository;
        this.customerRepository = customerRepository;
    }


    @PostMapping("/add/{productId}")
    public String addToCart(@PathVariable("productId") Long productId, HttpSession session) {
        // Kiểm tra xem người dùng đã đăng nhập chưa
        /*Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        if (authentication == null || !authentication.isAuthenticated()) {
            return "redirect:/login"; // Chuyển hướng đến trang đăng nhập nếu chưa đăng nhập
        }*/

        Product product = productRepository.findById(productId).orElse(null);

        if (product == null) {
            return "redirect:/error/404";
        }

        ShoppingCart cart = (ShoppingCart) session.getAttribute("cart");
        if (cart == null) {
            cart = new ShoppingCart();
            session.setAttribute("cart", cart);
        }

        cart.addItem(new CartItem(product, 1));
        return "redirect:/cart/view";
    }

    @PostMapping("/update/{productId}")
    public String updateQuantity(@PathVariable Long productId, @RequestBody Map<String, Integer> payload, HttpSession session) {
        ShoppingCart cart = (ShoppingCart) session.getAttribute("cart");
        if (cart != null) {
            int newQuantity = payload.get("quantity");
            cart.updateQuantity(productId, newQuantity);
            return "redirect:/cart/view"; // Chuyển hướng trở lại trang giỏ hàng
        }
        return "error/error";
    }





    @RequestMapping("/view")
    public String viewCart(Model model, HttpSession session) {
        ShoppingCart cart = (ShoppingCart) session.getAttribute("cart");
        if (cart != null) {
            model.addAttribute("cart", cart);
        } else {
            model.addAttribute("cart", new ShoppingCart());
        }
        return "cart";
    }

    /*@PostMapping("/checkout")
    public String checkout(@SessionAttribute("cart") ShoppingCart cart, Principal principal, HttpSession session) {
        if (cart == null || cart.getItems().isEmpty()) {
            return "redirect:/cart/view"; // Nếu giỏ hàng trống, không thể checkout
        }

        // Lấy thông tin khách hàng dựa trên người dùng hiện tại
        Customer customer = customerRepository.findByUser_Email(principal.getName());

        if (customer == null) {
            return "redirect:/error/404"; // Nếu không tìm thấy khách hàng
        }

        // Tạo đơn hàng mới
        Order order = new Order();
        order.setCustomer(customer);
        order.setOrderDate(LocalDate.now());
        order.setTotalAmount(cart.getTotalPrice());

        // Lưu các mục chi tiết đơn hàng
        List<OrderDetail> orderDetails = new ArrayList<>();
        for (CartItem item : cart.getItems()) {
            OrderDetail orderDetail = new OrderDetail();
            orderDetail.setProduct(item.getProduct());
            orderDetail.setQuantity(item.getQuantity());
            orderDetail.setPrice(item.getTotalPrice());
            orderDetail.setOrder(order);
            orderDetails.add(orderDetail);
        }
        order.setOrderDetails(orderDetails);

        // Lưu đơn hàng vào cơ sở dữ liệu
        orderRepository.save(order);

        // Xóa giỏ hàng sau khi thanh toán thành công
        session.removeAttribute("cart");

        return "redirect:/order/confirmation";
    }*/

    @RequestMapping("/checkout")
    public String showCheckoutPage(HttpSession session, Model model, Principal principal) {
        ShoppingCart cart = (ShoppingCart) session.getAttribute("cart");
        if (cart == null) {
            return "redirect:/cart/view";
        }

        // Lấy thông tin người dùng hiện tại
        String userEmail = principal.getName();
        Customer customer = customerRepository.findByUser_Email(userEmail); // Lấy thông tin Customer dựa trên email

        if (customer == null) {
            return "redirect:/login"; // Nếu không có thông tin người dùng, chuyển hướng đến trang đăng nhập
        }

        BigDecimal total = cart.getTotal();

        model.addAttribute("cart", cart);
        model.addAttribute("total", total);
        model.addAttribute("customer", customer); // Truyền thông tin Customer tới view

        return "checkout";
    }

    @PostMapping("/checkout/submit")
    public String submitOrder(HttpSession session, @SessionAttribute("user") User user,
                              @RequestParam("address") String address, @RequestParam("phone") String phone) {
        ShoppingCart cart = (ShoppingCart) session.getAttribute("cart");
        if (cart == null || cart.getItems().isEmpty()) {
            return "redirect:/cart/view";
        }

        Customer customer = customerRepository.findByUser(user);
        if (customer == null) {
            return "redirect:/login";
        }

        // Cập nhật địa chỉ và số điện thoại nếu người dùng thay đổi
        customer.setAddress(address);
        customer.setPhone(phone);
        customerRepository.save(customer);

        // Tạo đơn hàng và lưu vào cơ sở dữ liệu
        Order order = new Order();
        order.setCustomer(customer);
        order.setOrderDate(LocalDate.now());
        order.setTotalAmount(cart.getTotal());
        order.setStatus("Pending");
        order.setOrderDetails(new ArrayList<>());


        for (CartItem item : cart.getItems()) {
            OrderDetail detail = new OrderDetail();
            detail.setProduct(item.getProduct());
            detail.setQuantity(item.getQuantity());
            detail.setPrice(item.getProduct().getPrice());
            detail.setOrder(order);
            order.getOrderDetails().add(detail);
        }

        orderRepository.save(order);

        session.removeAttribute("cart");

        return "redirect:/order/confirmation";
    }
}

